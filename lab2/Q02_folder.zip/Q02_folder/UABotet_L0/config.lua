speedRatio = 1.0
serialPortNumber = "COM4"