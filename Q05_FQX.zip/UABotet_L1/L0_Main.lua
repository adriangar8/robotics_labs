-- L0 Main
-- By:      Lluis Ribas-Xirgo
--          Universitat Autonoma de Barcelona
-- Date:    September 2023
-- License: Creative Commons, BY-SA = attribution, share-alike
--          [https://creativecommons.org/licenses/by-sa/4.0/]

local me = sim.getObject("..")
local myname = sim.getObjectAlias(me, -1)
require(myname.."\\config")

  -- L0 UI interface
  L0_UI = {}
  L0_UI.xml = [[
    <ui title="L0 User Interface" resizable="true"
        style="background-color:lightBlue"
    >
      <group layout="hbox" flat="true">
      <group layout="vbox" flat="true">
      <group layout="hbox" flat="true">
      <label text="Angle" />
      <edit	id="110" value="0"
        on-editing-finished="L0_UI.updateAtext"
        style="background-color:white"
      />
      <label text="deg" />
      </group>
      <hslider id="115" minimum="-90" maximum="90" value="0" 
        tick-interval="10" tick-position="below" on-change="L0_UI.updateAslider" />
      <group layout="hbox" flat="true">
      <label text="Distance" />
      <edit	id="120" value="0"
        on-editing-finished="L0_UI.updateDtext"
        style="background-color:white"
      />
      <label text="cm" />
      </group>        
      <hslider id="125" minimum="0" maximum="255" value="0" 
        tick-interval="10" tick-position="below" on-change="L0_UI.updateDslider" />
      <group layout="hbox" flat="true">
      <button id="1" text="GO" style="background-color:lightGreen"
        on-click="L0_UI.GO" />
      <button id="4" text="HALT" style="background-color:red"
        on-click="L0_UI.HALT" />
      </group>
      <group layout="hbox" flat="true">
      <button id="2" text="LIDAR" style="background-color:lightGreen"
        on-click="L0_UI.LIDAR" />
      <button id="3" text="RESUME" style="background-color:lightGreen"
        on-click="L0_UI.RESUME" />
      </group>
      </group>

      <group layout="vbox" flat="true">
      <label text="From L0: "/>
      <text-browser id="40" text="..."
         html="false" read-only="true" style="align:left"
      />
      <!--tree id="40" show-header="false" style="align:left">
        <row> <item> ... </item> </row>
      </tree-->
      </group>

      </group>
    </ui>
  ]]
  L0_UI.handle = simUI.create(L0_UI.xml)
  simUI.setPosition(L0_UI.handle, 50, 450)
  L0_UI.angle = 0
  L0_UI.radius = 0
  L0_UI.C = nil
  L0_UI.L0msg = "..."
  L0_UI.updateAtext = function(uiHandle, id, newValue)
    local angle = tonumber(newValue)
    if angle then
      if angle < -90 then angle = -90 end
      if angle > 90 then angle = 90 end
      L0_UI.angle = angle
      simUI.setSliderValue(uiHandle, 115, angle)
    else
      angle = L0_UI.angle
    end
    simUI.setEditValue(uiHandle, 110, string.format("%d", angle))
  end
  L0_UI.updateAslider = function(uiHandle, id, newValue)
    L0_UI.angle = newValue
    simUI.setEditValue(uiHandle, 110, string.format("%d", newValue))
  end
  L0_UI.updateDtext = function(uiHandle, id, newValue)
    local radius = tonumber(newValue)
    if radius then
      if radius < 0 then radius = 0 end
      if radius > 255 then radius = 255 end
      L0_UI.radius = radius
      simUI.setSliderValue(uiHandle, 125, radius)
    else
      radius = L0_UI.radius
    end
    simUI.setEditValue(uiHandle, 120, string.format("%d", radius))
  end
  L0_UI.updateDslider = function(uiHandle, id, newValue)
    L0_UI.radius = newValue
    simUI.setEditValue(uiHandle, 120, string.format("%d", newValue))
  end
  L0_UI.GO = function(uiHandle, id)
    L0_UI.C = string.format("1 %d %d", L0_UI.angle, L0_UI.radius)
  end
  L0_UI.HALT = function(uiHandle, id) L0_UI.C = "4" end
  L0_UI.LIDAR = function(uiHandle, id) L0_UI.C = "2" end
  L0_UI.RESUME = function(uiHandle, id) L0_UI.C = "3" end
  L0_UI.setA = function(self, angle)
    if angle then
      if angle < -90 then angle = -90 end
      if angle > 90 then angle = 90 end
      self.angle = angle
      simUI.setLabelText(self.handle, 110, string.format("%d", angle))
      simUI.setSliderValue(self.handle, 115, angle)
    end
  end
  L0_UI.setD = function(self, radius)
    if angle then
      if radius < 0 then radius = 0 end
      if radius > 255 then radius = 255 end
      self.radius = radius
      simUI.setLabelText(self.handle, 120, string.format("%d", radius))
      simUI.setSliderValue(self.handle, 125, radius)
    end
  end
  L0_UI.getC = function(self)
    local C = self.C
    self.C = nil
    return C
  end
  L0_UI.appendM = function(self, M)
    self.L0msg = M..'\n'..self.L0msg
    simUI.setText(self.handle, 40, self.L0msg)
  end

  -- uncomment to hide UI ***
  simUI.hide(L0_UI.handle)       

L0Main = { init = function(self) self[1] = 17 self[2] = 1440 self[3] = 0 self[4] = nil self[7] = nil self[9] = nil self[8] = nil self[5] = nil self[6] = nil self[11] = {} self[10] = {} self[15] = {} self[14] = {} self[13] = {} self[12] = {} self[16] = {} self[17] = {} self.block = {} self.scan = {} self[20] = {} self[19] = {} self[18] = {} self.eticks2mm = self[1]*2*math.pi/self[2]  self.dW = 105 self.block.h = 2.5 self.block.t = 5 self.block.s = 8 self.scan = { -5, -10, -15, -20, -25, -30, -35, -40, -45, -50, -55, -60, -65, -70, -75, -80, -85, -90, -84, -78, -72, -66, -62, -54, -48, -42, -36, -32, -24, -18, -12, -6, 2, 6, 12, 18, 24, 32, 36, 42, 48, 54, 62, 66, 72, 78, 84, 90, 85, 80, 75, 70, 65, 60, 55, 50, 45, 40, 35, 30, 25, 20, 15, 10, 5, 0, 360 } self[9] = sim.getInt32Signal("enc_left") or 0 self[8] = sim.getInt32Signal("enc_right") or 0 self[10].prev = 2 self[10].next = 1 self[15].next = nil self[14].next = 0 self[13].next = 0 self[12].next = 0 self[16].next = 0 self[17].next = 0 self[20].next = 0 self[19].next = 0 self[18].next = false  self:forward() end, monitor = function(self) end, cmonitor = function(self) end, read_inputs = function(self, D, u) local data = sim.getStringSignal("L1L0v") if data==nil or #data==0 then data = L0_UI:getC() end if data and #data>0 then local words = {} for w in string.gmatch(data, "-?%d+") do table.insert(words, w) end self[11][1] = tonumber(words[1]) if (self[11][1] == 1) then if #words > 1 then self[11][2] = tonumber(words[2]) end if #words > 2 then self[11][3] = tonumber(words[3]) end end else self[11][1] = 0 end self[3] = sim.getSimulationTime() self[4] = D self[7] = u local cL = sim.getInt32Signal("enc_left") - self[9] local cR = sim.getInt32Signal("enc_right") - self[8] self[9] = self[9] + cL; self[8] = self[8] + cR; local dL = self.eticks2mm*cL local dR = self.eticks2mm*cR self[5] = (dR-dL)/self.dW self[5] = math.abs(self[5]*180/math.pi) self[6] = 0.5*(dL+dR) self[6] = self[6]/10.0 end, step = function(self) if (self[10].curr == 1) then if self[11][1]==0 then self[15].next = nil; self[12].next = 256; self[16].next = 256 elseif self[11][1]==1 then if (self[11][2]==nil or self[11][2] < -90 or self[11][2] > 90) then self[15].next = "E GO - -" self[12].next = 256; self[16].next = 256 elseif (self[11][3]==nil or self[11][3] < 0 or self[11][3] > 255) then self[15].next = "E GO "..self[11][2].." -" self[12].next = 256; self[16].next = 256 else self[13].next = self[11][3] self[15].next = nil if self[11][2]>0 then self[14].next = self[11][2]  self[12].next = 100; self[16].next = -100 self[10].next = 3 elseif self[11][2]<0 then self[14].next = -self[11][2]  self[12].next = -100; self[16].next = 100 self[10].next = 3 elseif self[11][3]>0 then self[12].next = 100; self[16].next = 100 self[10].next = 5 else self[12].next = 0; self[16].next = 0 self[15].next = "E GO 0 0" end end elseif self[11][1]==2 then self[10].next = 4 self[12].next = 0; self[16].next = 0 self[20].next = 1 elseif self[11][1]==3 then self[15].next = "E RESUME LISTEN?" self[12].next = 0; self[16].next = 0 elseif self[11][1]==4 then self[15].next = "E HALT LISTEN?" self[12].next = 0; self[16].next = 0 else self[15].next = "E Invalid opcode" self[12].next = 0; self[16].next = 0 end elseif self[10].curr==3 then local Anext = self[14].curr - self[5] if math.abs(Anext)<self[5]/2 then Anext = 0 end self[14].next = Anext if (self[11][1] == 4) then self[15].next = string.format( "D TURN HALTed, %ideg to go", math.floor(Anext)) self[12].next = 0; self[16].next = 0 self[10].next = 1 else  if self[11][1]~=0 then  self[15].next = "W Ignored command ("..self[11][1]..")" else self[15].next = nil; end if Anext==0 then if self[13].curr>0 then self[12].next = 100; self[16].next = 100 self[10].next = 5  else self[12].next = 0; self[16].next = 0 if self[11][1]==0 then self[15].next = "D GO OK" self[10].next = 1 end end end end elseif self[10].curr==5 then local Snext = self[13].curr - self[6] if math.abs(Snext)<self[6]/2 then Snext = 0 end self[13].next = Snext if self[11][1]==4 then self[15].next = string.format("D GO HALTed, %dcm to go", math.floor(Snext)) self[12].next = 0; self[16].next = 0 self[10].next = 1 else  if self[11][1]~=0 then  self[15].next = "W Ignored command ("..self[11][1]..")" else self[15].next = nil end if Snext>0 then if 0<self[4] and self[4]<=self.block.s then self[12].next = 0; self[16].next = 0 if self[11][1]==0 then self[15].next = string.format( "W BLOCKED, %icm to go", math.floor(Snext)) self[17].next = sim.getSimulationTime() self[10].next = 7 end else self[10].next = 5 end else self[12].next = 0; self[16].next = 0 if self[11][1]==0 then self[15].next = "D GO OK" self[10].next = 1 end end end elseif self[10].curr==7 then if (self[11][1] == 4) then self[15].next = string.format("D BLOCKED HALTed, %dcm to go", math.floor(self[13].curr)) self[12].next = 0; self[16].next = 0 self[10].next = 1 else  if (self[11][1] ~= 0) then  self[15].next = "W Ignored command ("..self[11][1]..")" else self[15].next = nil; end if sim.getSimulationTime()-self[17].curr < self.block.h then self[10].next = 7 elseif self[4] > self.block.s then self[12].next = 100; self[16].next = 100 self[10].next = 5 elseif sim.getSimulationTime()-self[17].curr < self.block.t then self[10].next = 7 else if self[11][1]==0 then self[15].next = string.format( "D BLOCKED, %icm to go", math.floor(self[13].curr)) self[10].next = 1 end end end elseif self[10].curr==4 then if self[11][1]==4 then self[15].next = "D LIDAR HALTed" self[10].next = 1 elseif (self[11][1] ~= 0) then  self[15].next = "W Ignored command ("..self[11][1]..")" else self[15].next = nil; if self.scan[self[20].curr]==360 then self[15].next = "D LIDAR OK" self[10].next = 1 else self[19].next = self.scan[self[20].curr] self[18].next = true self[10].next = 8 end end elseif self[10].curr==8 then if self[11][1]==4 then self[15].next = "D LIDAR ECHO HALTed" self[19].next = 0 self[18].next = true self[10].next = 10 else self[18].next = false if self[11][1]~=0 then  self[15].next = "W Ignored command ("..self[11][1]..")" else self[15].next = nil end if self[7] then self[20].next = self[20].curr + 1 self[10].next = 9 end end elseif self[10].curr==9 then if self[11][1]==4 then self[15].next = "D LIDAR RAY HALTed" self[19].next = 0 self[18].next = true self[10].next = 10 else  if self[11][1]~=0 then  self[15].next = "W Ignored command ("..self[11][1]..")" else self[15].next = string.format("D RAY %3i %3i", self[19].curr, self[4]) self[10].next = 6 end end elseif self[10].curr==6 then if self[11][1]==4 then self[15].next = "D RESUME HALTed" self[19].next = 0 self[18].next = true self[10].next = 10 elseif self[11][1]==3 then if self.scan[self[20].curr]==360 then self[15].next = "D LIDAR OK" self[19].next = 0 self[18].next = true self[10].next = 10 else  self[15].next = nil self[19].next = self.scan[self[20].curr] self[18].next = true self[10].next = 8 end elseif self[11][1]~=0 then  self[15].next = "W Ignored command ("..self[11][1]..")" else self[15].next = nil end elseif self[10].curr==10 then if self[11][1]~=0 then  self[15].next = "W Ignored command ("..self[11][1]..")" else self[15].next = nil end self[18].next = false if self[7] then self[10].next = 1 end elseif self[10].curr== "STOP" then self[15].next = nil else self[15].next = "E Undefined state!" self[10].next = "STOP" end end, write_outputs = function(self) if self[15].curr then sim.setStringSignal("L0vL1", self[15].curr) L0_UI:appendM(self[15].curr) else sim.setStringSignal("L0vL1", "") end sim.setInt32Signal("DC_left", self[12].curr) sim.setInt32Signal("DC_right", self[16].curr) end, get_target = function(self) return self[19].curr end, get_request = function(self) return self[18].curr end, forward = function(self) self[10].curr = self[10].next self[15].curr = self[15].next self[14].curr = self[14].next; self[13].curr = self[13].next self[12].curr = self[12].next; self[16].curr = self[16].next self[17].curr = self[17].next self[19].curr = self[19].next; self[18].curr = self[18].next self[20].curr = self[20].next end, active = function(self) return (self[10].curr==1) or (self[10].curr==3) or (self[10].curr==5) or (self[10].curr==7) or (self[10].curr==4) or (self[10].curr==8) or (self[10].curr==9) or (self[10].curr==6) or (self[10].curr==10) end } 