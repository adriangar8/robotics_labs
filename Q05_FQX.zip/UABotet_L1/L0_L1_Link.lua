-- L0-L1 Link
-- By:      Lluis Ribas-Xirgo
--          Universitat Autonoma de Barcelona
-- Date:    September 2023
-- License: Creative Commons, BY-SA = attribution, share-alike
--          [https://creativecommons.org/licenses/by-sa/4.0/]

local me = sim.getObject("..")
local myname = sim.getObjectAlias(me, -1)
require(myname.."\\config")
-- Defining the serial port number
serialPort="\\\\.\\" .. serialPortNumber
baudrate=9600
serialHandle=sim.serialOpen(serialPort, baudrate)
if(serialHandle == -1) then
   println("# L0Sync: Can't open "..serialPortNumber)
else
   println("# L0Sync: Serial port "..serialPortNumber.." is ready")
end

local L0sync = {
    C = nil,    -- Commands from L1
    D = nil,    -- Deadline for timeout sync, constant input
    V = nil,    -- Virtual message
    P = nil,    -- Previous characters from reality
    R = nil,    -- Real message
    T = nil,    -- Time
    state = {},
    B = {},     -- Begin time
    W = {},     -- Storage of last virtual message
    S = {},     -- Storage of last real message
    M = {},     -- L0sync to L1 message
    Z = {},     -- L0sync to L0 message
    robots = {},-- Number of connected robots
    init = function(self)
        self.state.prev = "NONE"
        self.state.curr = "INIT"; self.state.next = "INIT"
        self.D = 2.5 -- seconds of relative delay between reality and virtuality
        self.T = 0   -- system time
        self.B.curr = 0; self.B.next = 0 
        self.W.curr = nil; self.W.next = nil 
        self.S.curr = nil; self.S.next = nil
        self.M.curr = nil; self.M.next = nil
        self.Z.curr = nil; self.Z.next = nil
        self.robots.curr = 0; self.robots.next = 0
    end, -- function init()
    monitor = function(self)
        println(string.format("# L0Sync: state = %s", self.state.curr))
        if self.W.curr and #self.W.curr>0 then
            println("              W = " .. self.W.curr)
        end -- if
        if self.S.curr and #self.S.curr>0 then
            println("              S = " .. self.S.curr)
        end -- if            
    end, -- function monitor()
    cmonitor = function(self)
        if (self.state.prev~=self.state.curr) then
            self.state.prev = self.state.curr; self.monitor( self )
        end -- if
    end, -- function cmonitor()
    logger = function(self, mode)
        if not mode then mode = 0 end -- if mode not given, initialize
        if mode<0 then -- close log file
            if self.log and self.log.file then self.log.file:close() end
        elseif mode>0 then -- do the log
            if self.log and self.log.file then
                local realtime = sim.getSystemTime()
                if self.W.curr and #self.W.curr>0 then
                    self.log.file:write(string.format("%f;VIRTUAL L0;%s\n", 
                        realtime, self.W.curr))
                end -- if
                if self.S.curr and #self.S.curr>0 then
                    self.log.file:write(string.format("%f;REAL L0;%s\n", 
                        realtime, self.S.curr))
                end -- if
                if self.Z.curr and #self.Z.curr>0 then
                    self.log.file:write(string.format("%f;MIXED L1;%s\n", 
                        realtime, self.Z.curr))
                end -- if
            end -- if
        else -- open log file
            if not self.log then self.log = {} end
            local filename = sim.getStringParam(sim.stringparam_scene_path)..
                "\\L0L1Link_log.csv"
            self.log.file = io.open(filename, "a")
        end -- if
    end,
    read_inputs = function(self)
        self.C = sim.getStringSignal("L1L0")
        if self.C and self.C=="" then self.C = nil end
        self.V = sim.getStringSignal("L0vL1")
        if self.V and self.V=="" then self.V = nil end
        if serialHandle ~= -1 then -- serial port attached
            local numChar = sim.serialCheck(serialHandle)
            if numChar>0 then
                local reply = sim.serialRead(serialHandle, numChar, false)
                if not self.P then self.P = reply else self.P = self.P..reply end
                if string.sub(reply, #reply, #reply)=='\n' then
                    self.R = self.P; self.P = nil
                else
                    self.R = nil
                end -- if
            else
                self.R = nil
            end -- if numChar
        end -- if
        if self.C then println("> L0Sync: L1->L0{v|r}, C = "..self.C) end
        if self.V then println("> L0Sync: L0v->L1, V = "..self.V) end
        if self.R then println("> L0Sync: L0r->L1, R = "..self.R) end
        self.T = sim.getSystemTime()
    end, -- function read_inputs()
    step = function(self)
        if self.state.curr == "INIT" then
            if serialHandle~=-1 then
                self.B.next = self.T
                self.Z.next = "4"
                self.state.next = "WAIT"
            else
                self.robots.next = 1
                self.state.next = "VIRTUAL"
            end                
        elseif self.state.curr == "WAIT" then
            self.Z.next = nil
            if self.R then
                self.robots.next = 2
                self.state.next = "REAL"
            elseif self.T-self.B.curr>self.D then
                println("# L0Sync: Serial port "..serialPortNumber.." is not responding.")
                serialHandle = -1 -- open for some other reason
                self.robots.next = 1
                self.state.next = "VIRTUAL"
            end -- if-elseif
        elseif self.state.curr == "REAL" then
            self.S.next = self.R
            self.W.next = self.V
            self.Z.next = self.C
            self.M.next = self.R
        elseif self.state.curr == "VIRTUAL" then
            self.S.next = self.R
            self.W.next = self.V
            self.Z.next = self.C
            self.M.next = self.V
        elseif self.state.curr == "SYNC" then
            self.S.next = self.R
            self.W.next = self.V
            if self.V == self.R then
                self.M.next = self.V
            else
                self.M.next = nil
            end -- if
        elseif self.state.curr == "AHEAD" then
        elseif self.state.curr == "HALT" then
        elseif self.state.curr == "BEHIND" then
        elseif self.state.curr == "ADD" then
        else -- self.state.curr == "STOP" or ERROR!
            self.state.next = "STOP"
        end -- if chain
    end, -- function step()
    write_outputs = function(self)
        if self.Z.curr then
            sim.setStringSignal("L1L0v", self.Z.curr) -- send message to virtual L0
            if self.state.curr=="WAIT" or self.state.curr=="REAL" then
                sim.serialSend(serialHandle, self.Z.curr)
            end -- if
        else
            sim.setStringSignal("L1L0v", "")
        end -- if
        if self.M.curr then
            sim.setStringSignal("L0L1", self.M.curr) -- send message to L1
        else
            sim.setStringSignal("L0L1", "")
        end -- if
        sim.setInt32Signal("L0L1robots", self.robots.curr)
    end, -- function write_outputs()
    forward = function(self)
        self.state.curr = self.state.next
        self.B.curr = self.B.next
        self.W.curr = self.W.next
        self.S.curr = self.S.next
        self.M.curr = self.M.next
        self.Z.curr = self.Z.next
        self.robots.curr = self.robots.next
    end, -- function forward()
    active = function( self )
        return (self.state.curr == "SYNC")   or 
               (self.state.curr == "AHEAD")  or (self.state.curr == "HALT") or
               (self.state.curr == "BEHIND") or (self.state.curr == "ADD")
    end -- function active()        
} -- L0sync module

return L0sync